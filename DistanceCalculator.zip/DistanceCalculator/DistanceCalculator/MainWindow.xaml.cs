﻿using System;
using System.IO;
using System.Text;
using System.Windows;

namespace DistanceCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string hours;
        string speed;

        const string FILENAME = "output.txt";

        readonly StringBuilder output = new StringBuilder();
        readonly string fullName;
        public MainWindow()
        {
            InitializeComponent();

            string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Distance");

            if (!Directory.Exists(filePath))
                Directory.CreateDirectory(filePath);

            fullName = Path.Combine(filePath, FILENAME);

        }
        private void btnSpeed_Click(object sender, RoutedEventArgs e)
        {
            string speed = txtSpeed.Text;
            double speedDouble;

            if (speed == "")
            {
                lblError.Content = "Enter a number";
            }
            else
            {
                lblError.Content = "";
                try
                {
                    speedDouble = double.Parse(speed);
                    if (speedDouble <= 0)
                    {
                        lblError.Content = "Number must be greater than 0";
                    }
                    else
                    {
                        panelSpeed.Visibility = Visibility.Hidden;
                        panelHours.Visibility = Visibility.Visible;
                        lblError.Content = "";
                    }
                }
                catch (FormatException)
                {
                    lblError.Content = "Enter a number";
                }

            }

        }

        private void btnHours_Click(object sender, RoutedEventArgs e)
        {
            string hours = txtHours.Text;
            string speed = txtSpeed.Text;

            if (hours == "")
            {
                lblError.Content = "Enter a number";
            }
            else
            {
                lblError.Content = "";   
                try
                {
                    double hoursDouble = double.Parse(hours);
                    double doubleSpeed = double.Parse(speed);
                    if (hoursDouble <= 0)
                    {
                        lblError.Content = "Number must be greater than 0";
                    }
                    else
                    {
                        panelHours.Visibility = Visibility.Hidden;
                        panelCalc.Visibility = Visibility.Visible;
                        lblError.Content = "";
                        lblCalc.Content = $"Speed = {doubleSpeed}, total hours = {hoursDouble}";
                    }
                }
                catch (FormatException)
                {
                    lblError.Content = "Enter a number";
                }
            }
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            distanceTravelled.Visibility = Visibility.Visible;
            lblCalc.Content = "";
            hours = txtHours.Text;
            speed = txtSpeed.Text;
            int intHours = int.Parse(hours);
            int intSpeed = int.Parse(speed);
            for (int x = 1; x <= intHours; ++x)
            {
                int distance = x * intSpeed;
                distanceTravelled.Items.Add("Hour " + x + ", distance = " + distance);
                output.Append($"Hour {x}:{" Speed was "}{intSpeed}, Distance traveled was {distance}{Environment.NewLine}");
            }

            output.AppendLine();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            distanceTravelled.Visibility = Visibility.Hidden;
            File.AppendAllText(fullName, output.ToString());
            output.Clear();
            distanceTravelled.Items.Clear();
            panelCalc.Visibility = Visibility.Hidden;
            lblCalc.Content = "Output Saved!";
            btnRestart.Visibility = Visibility.Visible;
        }

        private void btnRestart_Click(object sender, RoutedEventArgs e)
        {
            panelSpeed.Visibility = Visibility.Visible;
            btnRestart.Visibility = Visibility.Hidden;
            lblCalc.Visibility = Visibility.Hidden;
            txtHours.Text = "";
            txtSpeed.Text = "";
        }
    }
}
